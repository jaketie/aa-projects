const isBigger = (num1, num2, flag) => {
  let bigNum;
  let smallNum;
  if (num1 > num2) {
    bigNum = num1;
    smallNum = num2;
  } else {
    bigNum = num2;
    smallNum = num1;
  }
  if (flag === 'big') {
    return bigNum;
  } else if (flag === 'small') {
    return smallNum;
  }
}

function multiplyBiggerNumByTwo(num1, num2) {
  return isBigger(num1, num2, 'big') * 2;
}

function divideBiggerNumByThree(num1, num2) {
  return isBigger(num1, num2, 'big') / 3;
}

function eatMostTacos(sum1, sum2) {
  return `I ate ${isBigger(sum1, sum2, 'big')} tacos.`;
}

function adoptSmallerDog(weight1, weight2) {
  return `I adopted a dog that weighs ${isBigger(weight1, weight2, 'small')} pounds.`;
}


/**************************************************************************/
/* DO NOT CHANGE THE CODE BELOW */
module.exports = {
  multiplyBiggerNumByTwo,
  divideBiggerNumByThree,
  eatMostTacos,
  adoptSmallerDog
};
